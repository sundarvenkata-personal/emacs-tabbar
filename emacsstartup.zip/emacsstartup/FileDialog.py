from Tkinter import *
import tkFileDialog

root = Tk()
root.withdraw()
FileList = tkFileDialog.askopenfilenames()

LispString = "(mapcar 'find-file "
LispString += "'("

for fileName in FileList:
    LispString += '"'
    LispString += fileName
    LispString += '"'
    if fileName != FileList[-1]:
        LispString += " "

LispString += "))"

print LispString

